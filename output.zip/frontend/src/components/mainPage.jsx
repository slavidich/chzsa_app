import React from "react";
import '../styles/mainPage.scss'

function MainPage(){
    return(
    <>
    <div className='mainpage'>
        <p>Главная страница</p>
    </div>
    </>)
}

export default MainPage