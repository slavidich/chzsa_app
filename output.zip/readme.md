backend - django + drf 

fronend - react + redux 

бд - postgresql (docker). pgadmin 

Для запуска django: 

1. python -m venv venv

2. ./venv/scripts/activate

3. pip install -r ./requirements.txt

4. python ./chzsa/manage.py runserver

